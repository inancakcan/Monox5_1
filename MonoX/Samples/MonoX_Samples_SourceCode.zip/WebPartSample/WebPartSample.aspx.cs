using System;

namespace MonoSoftware.MonoX.Samples
{
    public partial class WebPartSample : BasePage
    {
    }
}
