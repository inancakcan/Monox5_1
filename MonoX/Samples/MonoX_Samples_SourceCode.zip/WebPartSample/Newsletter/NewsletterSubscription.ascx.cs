﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using MonoSoftware.MonoX.Utilities;
using MonoSoftware.MonoX.Repositories;
using MonoSoftware.MonoX.Resources;
using MonoSoftware.MonoX.API;
using System.Web.Security;
using MonoSoftware.MonoX.DAL.HelperClasses;
using MonoSoftware.MonoX.DAL.EntityClasses;
using MonoSoftware.Web;
using MonoSoftware.Core;
using System.Collections;
using NVelocity;
using System.Net.Mail;
using MonoSoftware.MonoX.Mail;
using MonoSoftware.MonoX.Caching;
using MonoSoftware.MonoX.DependencyInjection;
using MonoSoftware.MonoX.Common.DependencyInjection;
using MonoSoftware.MonoX.BusinessLayer;

namespace MonoSoftware.MonoX.Samples
{
    /// <summary>
    /// Web part that provides the possibility for the users to subscribe or unsubscribe from the newsletters.
    /// </summary>
    [WebPartCatalogCategory("Samples")]
    public partial class NewsletterSubscription : BaseAutoRegisterPart
    {
        #region Properties
        private Guid[] _newslettersSubscriptionRoleIds;
        /// <summary>
        /// Gets or sets newsletter subscription roles.
        /// </summary>
        [WebBrowsable(true), Personalizable(true)] 
        [WebEditor(typeof(RoleEditorPart))]
        [WebDescription("List of newsletter subscription role ids which are visible to the users.")]
        [WebDisplayName("Newsletter subscription role ids")]
        public virtual Guid[] NewsletterSubscriptionRoleIds
        {
            get { return _newslettersSubscriptionRoleIds; }
            set
            {
                _newslettersSubscriptionRoleIds = value;
            }
        }

        private string _newsletterSubscriptionRoles;
        /// <summary>
        /// Gets or sets newsletter subscription roles (separated by commas or semicolons) with the names of roles that will receive newsletters. All the roles used by this propery have to be previously created in the portal administration area.
        /// </summary>
        public virtual string NewsletterSubscriptionRoles
        {
            get { return _newsletterSubscriptionRoles; }
            set
            {
                _newsletterSubscriptionRoles = value;
                this.NewsletterSubscriptionRoleIds = SecurityUtility.GetRoleIds(value);
            }
        }

        private string _newsletterSubscriptionMailContent = String.Empty;
        /// <summary>
        /// Gets or sets newsletter subscription mail content.
        /// </summary>
        [WebBrowsable(true), Personalizable(true)]
        [WebEditor(typeof(TextAreaEditorPart))]
        [WebDescription("Newsletter subscription mail content")]
        [WebDisplayName("Newsletter subscription mail content")]
        public string NewsletterSubscriptionMailContent
        {
            get 
            {
                if (String.IsNullOrEmpty(_newsletterSubscriptionMailContent))
                {
                    string templatesPath = String.Format("{0}/{1}", PageUtility.GetTemplateFolder(), "GenericTemplates");
                    _newsletterSubscriptionMailContent = MonoXUtility.GetTemplateHtml(templatesPath, "NewsletterSubscriptionMail");
                }
                return _newsletterSubscriptionMailContent; }
            set 
            { 
                _newsletterSubscriptionMailContent = value; 
            }
        }

        private string _newsletterSubscriptionMailSubject = Newsletter.Unsubscription_Mail_Subject;
        /// <summary>
        /// Gets or sets newsletter subscription mail subject.
        /// </summary>
        [WebBrowsable(true), Personalizable(true)]
        [WebDescription("Newsletter subscription mail subject")]
        [WebDisplayName("Newsletter subscription mail subject")]
        public string NewsletterSubscriptionMailSubject
        {
            get
            {
                return _newsletterSubscriptionMailSubject;  
            }
            set { _newsletterSubscriptionMailSubject = value; }
        }
       
        private bool _enableNewsletterSubscription = true;
        /// <summary>
        ///Gets or sets a value indicating whether newsletter subscription is enabled. 
        /// </summary>
        [WebBrowsable(true), Personalizable(true)]
        [WebDescription("Enable newsletter subscription")]
        [WebDisplayName("Enable newsletter subscription")]
        public bool EnableNewsletterSubscription
        {
            get 
            {
                return _enableNewsletterSubscription;
            }
            set
            {
                _enableNewsletterSubscription = value;
            }
        }
        private bool _enableNewsletterUnsubscription = true;
        /// <summary>
        ///Gets or sets a value indicating whether newsletter unsubscription is enabled. 
        /// </summary>
        [WebBrowsable(true), Personalizable(true)]
        [WebDescription("Enables newsletter unsubscription")]
        [WebDisplayName("Enable newsletter unsubscription")]
        public bool EnableNewsletterUnsubscription
        {
            get
            {
                return _enableNewsletterUnsubscription;
            }
            set
            {
                _enableNewsletterUnsubscription = value;
            }
        }

        private string _newsletterSubscriptionTitle = Newsletter.Subscription_Title;
        /// <summary>
        /// Gets or sets the subscription title.
        /// </summary>
        [WebBrowsable(true), Personalizable(true)]
        [WebDescription("Newsletter subscription title")]
        [WebDisplayName("Newsletter subscription title")]
        public string NewsletterSubscriptionTitle
        {
            get
            {
                return _newsletterSubscriptionTitle;
            }
            set { _newsletterSubscriptionTitle = value; }
        }

        private string _newsletterUnsubscriptionTitle = Newsletter.Unubscription_Title;
        /// <summary>
        /// Gets or sets the unsubscription title.
        /// </summary>
        [WebBrowsable(true), Personalizable(true)]
        [WebDescription("Newsletter subscription title")]
        [WebDisplayName("Newsletter subscription title")]
        public string NewsletterUnsubscriptionTitle
        {
            get
            {
                return _newsletterUnsubscriptionTitle;
            }
            set { _newsletterUnsubscriptionTitle = value; }
        }

        private string _newsletterSubscriptionDescription = Newsletter.Subscription_Description;
        /// <summary>
        /// Gets or sets the subscription description.
        /// </summary>
        [WebBrowsable(true), Personalizable(true)]
        [WebDescription("Newsletter subscription description")]
        [WebDisplayName("Newsletter subscription description")]
        public string NewsletterSubscriptionDescription
        {
            get
            {
                return _newsletterSubscriptionDescription;
            }
            set { _newsletterSubscriptionDescription = value; }
        }

        private string _newsletterUnsubscriptionDescription = Newsletter.Unsubscription_Description;
        /// <summary>
        /// Gets or sets the unsubscription description.
        /// </summary>
        [WebBrowsable(true), Personalizable(true)]
        [WebDescription("Newsletter unsubscription description")]
        [WebDisplayName("Newsletter unsubscription description")]
        public string NewsletterUnsubscriptionDescription
        {
            get
            {
                return _newsletterUnsubscriptionDescription;
            }
            set { _newsletterUnsubscriptionDescription = value; }
        }


        private EntityCollection<AspnetRolesEntity> NewsletterRoles
        {
            get
            {
                if (NewsletterSubscriptionRoleIds != null)
                    return DependencyInjectionFactory.Resolve<IMembershipBLL>().
							GetRoles(NewsletterSubscriptionRoleIds);
                else
                    return null;
            }
        }

        private Guid[] UserRoles
        {
            get
            {
                return SecurityUtility.UserRoleIds();
            }
        }
        #endregion

        #region Constructor
        public NewsletterSubscription()
        {
            Title = "Newsletter subscription";
            this.CatalogIconImageUrl = Paths.App_Themes.All.Common.img.parts.General.html_editor_png;
        }
        #endregion

        #region Page Events
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            btnSubscribe.Text = Newsletter.Button_Subscribe;
            btnUnsubscribe.Text = Newsletter.Button_Unsubscribe;

            btnSubscribe.Click += new EventHandler(btnSubscribe_Click);
            btnUnsubscribe.Click += new EventHandler(btnUnsubscribe_Click);             
        }

        protected override void OnLoad(EventArgs e)
        {            
            if (UrlParams.UserId.HasValue && UrlParams.NewsletterUnsubscriptionId.HasValue)
            { 
                MembershipUser membershipUser = Membership.GetUser(UrlParams.UserId.Value.Guid);
                plhSubscription.Visible = false;
                String roleName = String.Empty;

                if (membershipUser != null && NewsletterRoles != null)
                {
                    try
                    {
                        AspnetRolesEntity role = NewsletterRoles.FirstOrDefault(p => p.RoleId == UrlParams.NewsletterUnsubscriptionId.Value.Guid);
                        if (role != null)
                        {
                            roleName = role.RoleName;
                            Roles.RemoveUserFromRole(membershipUser.UserName, roleName);
                            SecurityUtility.RemoveRoleIdFromCache(membershipUser.UserName);
                            lblMessage.Text = String.Format(Newsletter.Unsubscription_Success_Message, roleName);
                            DataBind();
                        }
                    }
                    catch
                    {
                        lblMessage.Text = String.Format(Newsletter.ErrorMessage_NewsletterUnsubscription, roleName);
                    }
                }
                else
                {
                    lblMessage.Text = String.Format(Newsletter.ErrorMessage_NewsletterUnsubscription, roleName);
                }
            }
            base.OnLoad(e);
        }
        protected override void OnPreRender(EventArgs e)
        {            
            plhSubscription.Visible = EnableNewsletterSubscription;
            plhUnsubscription.Visible = EnableNewsletterUnsubscription;

            if (NewsletterRoles != null)
            {
                plhSubscription.Visible = NewsletterRoles.Any(p => !UserRoles.Contains(p.RoleId));
                plhUnsubscription.Visible = NewsletterRoles.Any(p => UserRoles.Contains(p.RoleId));
            }
            else if ((NewsletterRoles == null) ||
                !Page.User.Identity.IsAuthenticated)
            {
                if (!Page.User.Identity.IsAuthenticated)
                    lblMessage.Text = Newsletter.UnloggedUser_Message;
                else
                    lblMessage.Text = Newsletter.UndefinedRoles_Message;
                plhSubscription.Visible = false;
                plhUnsubscription.Visible = false;
            }
            base.OnPreRender(e);
        }
        #endregion

        #region Methods
        /// <summary>
        /// Raised after personalization data is applied to the specified System.Web.UI.WebControls.WebParts.WebPart
        /// control when requested to do so by the parent System.Web.UI.WebControls.WebParts.WebPartManager 
        /// control.
        /// </summary>
        /// <param name="webPart">The Web Parts control to which personalization data is to be applied.</param>
        public override void AppliedPersonalizationState(WebPart webPart)
        {
            base.AppliedPersonalizationState(webPart);
            if (Page.User.Identity.IsAuthenticated)           
                DataBind();
        }

        /// <summary>
        /// Binds newsletter roles for the display in the two checkboxlists.
        /// </summary>
        public override void DataBind()
        {
            if (NewsletterSubscriptionRoleIds != null)
            {
                if (Page.User.Identity.IsAuthenticated)
                {
                    if (EnableNewsletterSubscription)
                    {
                        cblNewsletterSubscriptionRoles.DataTextField = "RoleName";
                        cblNewsletterSubscriptionRoles.DataValueField = "RoleId";
                        IEnumerable<AspnetRolesEntity> newsletterSubscriptionRoles = NewsletterRoles.Where(p => !UserRoles.Contains(p.RoleId));
                        cblNewsletterSubscriptionRoles.DataSource = newsletterSubscriptionRoles;
                        cblNewsletterSubscriptionRoles.DataBind();
                    }
                    if (EnableNewsletterUnsubscription)
                    {
                        cblNewsletterUnsubscriptionRoles.DataTextField = "RoleName";
                        cblNewsletterUnsubscriptionRoles.DataValueField = "RoleId";
                        IEnumerable<AspnetRolesEntity> newsletterUnsubscriptionRoles = NewsletterRoles.Where(p => UserRoles.Contains(p.RoleId));
                        cblNewsletterUnsubscriptionRoles.DataSource = newsletterUnsubscriptionRoles;
                        cblNewsletterUnsubscriptionRoles.DataBind();
                    }
                }
            }
        }

        /// <summary>
        /// Parses all template tags and generates a proper HTML based on the current template.
        /// </summary>
        /// <param name="isPlainText">Is this a plain text template</param>
        /// <param name="newslettersSubscriptionroles">Newsletter roles</param>
        /// <param name="velocityContext">Velocity context</param>
        /// <returns></returns>
        protected virtual Hashtable ParseTemplateTags(bool isPlainText, List<KeyValuePair<string, string>> newslettersSubscriptionroles, ref NVelocity.VelocityContext velocityContext)
        {
            Hashtable tags = new Hashtable();

            if ((newslettersSubscriptionroles.Count > 0))
            {
                tags.Add("<# Message #>", String.Format(Newsletter.Unsubcription_MailTemplate_Message, Page.User.Identity.Name ));

                List<object> rolesItems = new List<object>();

                foreach (KeyValuePair<string, string> role in newslettersSubscriptionroles)
                {
                    string newsletterSubscriptionLink = role.Key; 
                    if (!isPlainText)
                    {
                        HyperLink lnkNewsletterRole = new HyperLink();
                        lnkNewsletterRole.Text = role.Value;
                        lnkNewsletterRole.ToolTip =  String.Format(Resources.Newsletter.Unsubscription_MailTemplate_Tooltip, role.Key);
                        lnkNewsletterRole.NavigateUrl = newsletterSubscriptionLink;
                        newsletterSubscriptionLink = MonoXUtility.Render(lnkNewsletterRole);
                    }
                    rolesItems.Add(newsletterSubscriptionLink);
                }

                velocityContext.Put("Roles", rolesItems);
            }

            return tags;
        }

        #endregion

        #region UI events
        void btnSubscribe_Click(object sender, EventArgs e)
        {
            List<KeyValuePair<string, string>> newsletterSubscriptionLinks = new List<KeyValuePair<string, string>>();
            foreach (ListItem item in cblNewsletterSubscriptionRoles.Items)
            {
                if (item.Selected)
                {
                    if (!Roles.IsUserInRole(item.Text))
                    {
                        Roles.AddUserToRole(Page.User.Identity.Name, item.Text);
                        SecurityUtility.RemoveRoleIdFromCache(Page.User.Identity.Name);
                        string newsletterSubscriptionLink = UrlFormatter.ResolveServerUrl("~/").Append(UrlParams.UserId, new ShortGuid(SecurityUtility.GetUserId())).Append(UrlParams.NewsletterUnsubscriptionId, new ShortGuid(new Guid(item.Value)));
                        newsletterSubscriptionLinks.Add(new KeyValuePair<string, string>(newsletterSubscriptionLink, item.Text));
                        lblMessage.Text = String.Format(Newsletter.Subscription_Success_Message, item.Text);
                        
                    }
                }
            }

            if (newsletterSubscriptionLinks.Count > 0)
            {
                VelocityContext velocityContext = new VelocityContext();
                VelocityContext velocityContextPlain = new VelocityContext();

                Hashtable tags = ParseTemplateTags(false, newsletterSubscriptionLinks, ref velocityContext);
                Hashtable tagsPlain = ParseTemplateTags(true, newsletterSubscriptionLinks, ref velocityContextPlain);

                string template = MonoXUtility.RenderMonoXTemplate(NewsletterSubscriptionMailContent, tags, velocityContext, null);
                string templatePlain = MonoXUtility.RenderMonoXTemplate(NewsletterSubscriptionMailContent, tagsPlain, velocityContextPlain, null);

                MailMessage mailMsg = DependencyInjectionFactory.Resolve<IMonoXMailSender>().CreateMailMessage(Page.User.GetMembershipUser().Email, ApplicationSettings.MailFromAddress, NewsletterSubscriptionMailSubject, template, null);
                mailMsg.AlternateViews.Add(AlternateView.CreateAlternateViewFromString(template, null, "text/html"));
                mailMsg.AlternateViews.Add(AlternateView.CreateAlternateViewFromString(HtmlFormatter.EncodeBreaks(HtmlFormatter.StripTags(templatePlain, true)), null, "text/plain"));

                try
                {
                    DependencyInjectionFactory.Resolve<IMonoXMailSender>().SendMail(mailMsg);

                }
                catch (Exception exception)
                {
                    lblMessage.Text = ErrorMessages.EmailSendingFailed;
                    log.Error(exception);
                }

                DataBind();
            }
        }
        void btnUnsubscribe_Click(object sender, EventArgs e)
        {
            foreach (ListItem item in cblNewsletterUnsubscriptionRoles.Items)
            {
                if (item.Selected && Roles.IsUserInRole(item.Text))
                {
                    Roles.RemoveUserFromRole(Page.User.Identity.Name, item.Text);
                    SecurityUtility.RemoveRoleIdFromCache(Page.User.Identity.Name);
                    lblMessage.Text = String.Format(Newsletter.Unsubscription_Success_Message, item.Text);
                }
            }
            DataBind();
        }
        #endregion
    }
}