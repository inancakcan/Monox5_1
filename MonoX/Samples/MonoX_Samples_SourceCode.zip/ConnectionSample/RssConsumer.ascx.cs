using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Net;
using System.Text;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml;

namespace MonoSoftware.MonoX.Samples
{
    public partial class RssConsumer : BasePart
    {
        private IStringConnectionInterface _providerData = null;

        private string _url = string.Empty;

        public string Url
        {
            get
            {
                if (_providerData != null)
                {
                    return _providerData.StringParameter;
                }
                else
                {
                    return string.Empty;
                }
            }
            set { _url = value; }
        }

        private int _maxItems = 10;

        public int MaxItems
        {
            get { return _maxItems; }
            set { _maxItems = value; }
        }
	
        [ConnectionConsumer("RSS consumer", "RssConsumer")]
        public void SetProviderData(IStringConnectionInterface providerData)
        {
            this._providerData = providerData;
        }

        public RssConsumer()
        {
            Title = "RSS consumer";
        }

        protected override void OnLoad(EventArgs e)
        {            
            dlRss.RepeatColumns = 1;
            dlRss.RepeatDirection = RepeatDirection.Vertical;
            dlRss.RepeatLayout = RepeatLayout.Flow;
            base.OnLoad(e);
        }

        protected override void OnPreRender(EventArgs e)
        {            
            List<RSSFeed> FeedList = null;
            try
            {
                FeedList = (List<RSSFeed>)GetFeeds(this.MaxItems, 0);
            }
            catch { }
            dlRss.DataSource = FeedList;
            dlRss.DataBind();
            base.OnPreRender(e);
        }


        //the ReadXml doesn't care about namespaces - it tries to create a column "title" for the XML tag "title" - and also tries to create a column "title" for the dc:title tag (namespaces are common in the RSS 2.0), which gives us the name collision.The following method fixes this situation.
        private string FixNamespaces(string url)
        {
            XmlTextReader reader = null;
            StringBuilder builder = new StringBuilder();
            string rssXml = string.Empty;
            try
            {
                try
                {
                    HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                    request.Timeout = 10000;

                    using (Stream stream = request.GetResponse().GetResponseStream())
                    using (StreamReader sReader = new StreamReader(stream))
                    {
                        rssXml = sReader.ReadToEnd();
                    }
                    //reader = new XmlTextReader(url);
                    reader = new XmlTextReader(rssXml, XmlNodeType.Document, null);
                }
                catch
                {
                    return string.Empty;
                }
                reader.WhitespaceHandling = WhitespaceHandling.None;
                bool isEmptyElement = false;
                while (reader.Read())
                {
                    string name = reader.Name.Replace(":", "_");
                    if (reader.NodeType == System.Xml.XmlNodeType.Element)
                    {
                        isEmptyElement = reader.IsEmptyElement;
                        //Add the element... 
                        builder.Append("<" + name);
                        if (reader.HasAttributes)
                        {
                            while (reader.MoveToNextAttribute())
                            {
                                name = reader.Name.Replace(":", "_");
                                builder.AppendFormat(" " + name + "=\"" + reader.Value + "\"");
                            }
                        }
                        if (isEmptyElement)
                            builder.Append("/>");
                        else
                            builder.Append(">");
                    }
                    else if (reader.NodeType == System.Xml.XmlNodeType.Text || reader.NodeType == XmlNodeType.CDATA)
                    {
                        builder.Append(System.Web.HttpUtility.HtmlEncode(reader.Value));
                    }
                    else if (reader.NodeType == System.Xml.XmlNodeType.EndElement)
                    {
                        builder.Append("</" + name + ">");
                    }

                }
                reader.Close();
            }
            catch
            {
                if (reader != null)
                {
                    reader.Close();
                    return string.Empty;
                }
            }
            return builder.ToString();

        }

        public ICollection<RSSFeed> GetFeeds(int maxRows, int startRowIndex)
        {
            List<RSSFeed> list = null;

            list = new List<RSSFeed>();
            DataSet ds = new DataSet();
            StringReader reader = new StringReader(FixNamespaces(this.Url));
            try
            {
                ds.ReadXml(reader, XmlReadMode.Auto);
            }
            catch
            {
                if (reader != null) reader.Close();
            }
            DataTable dt = null;
            foreach (DataTable tbl in ds.Tables)
            {
                if (tbl.TableName.ToLower() == "item")
                    dt = tbl;
            }
            if (dt == null)
                return null;

            foreach (DataRow row in dt.Rows)
            {
                string title = (string)row["title"];
                string description = (string)row["description"];
                string link = (string)row["link"];
                DateTime pubDate = DateTime.Now;
                try
                {
                    pubDate = Convert.ToDateTime(row["pubDate"]);
                }
                catch { }
                list.Add(new RSSFeed(title, description, link, pubDate));
            }
            List<RSSFeed> retList;
            if (maxRows > 0)
            {
                if (list.Count < maxRows) maxRows = list.Count;
                retList = new List<RSSFeed>();
                for (int i = startRowIndex; i < maxRows; i++)
                {
                    retList.Add(list[i]);
                }
            }
            else
            {
                retList = list;
            }
            return retList;
        }

    }

    public class RSSFeed
    {
        private string _title;
        public string Title
        {
            get { return _title; }
            set { _title = value; }
        }

        private string _description;
        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }

        private string _link;
        public string Link
        {
            get { return _link; }
            set { _link = value; }
        }

        private DateTime _pubDate;
        public DateTime PubDate
        {
            get { return _pubDate; }
            set { _pubDate = value; }
        }

        public RSSFeed(string title, string description, string link, DateTime pubDate)
        {
            this._title = title;
            this._description = description;
            this._link = link;
            this._pubDate = pubDate;
        }
    }
}